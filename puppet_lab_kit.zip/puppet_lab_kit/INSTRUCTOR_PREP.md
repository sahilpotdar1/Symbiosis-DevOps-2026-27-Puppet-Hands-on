# Instructor pre-class preparation

## Strong recommendation

Do a complete dry run on one current macOS machine and one current Windows 11 + Ubuntu WSL machine before class. Puppet's official package access is authenticated in the current Puppet Core 9 distribution, so do not make students discover authentication/package-access issues for the first time during the lecture.

## Preferred classroom installation strategy

Option A (best for a live class): download the current official Puppet Core installer for macOS and the Windows/Ubuntu package through the Puppet Core free/testing access flow ahead of time, then distribute the exact installer/package through your institution's approved student channel.

Option B: each student follows the authenticated Puppet Core free-access setup in the student guide.

For Windows, this lab deliberately uses WSL Ubuntu rather than native Windows Puppet so that package management uses the standard Debian/Ubuntu `apt` provider and the same Unix-like manifests can be followed as on macOS.

## Test these commands before class

macOS:

```bash
puppet --version
facter --version
puppet apply --version
brew --version
```

WSL Ubuntu:

```bash
puppet --version
facter --version
puppet apply --version
lsb_release -a
```

Then from the lab root:

```bash
puppet apply --modulepath=modules --noop manifests/01_basics.pp
puppet apply --modulepath=modules --noop manifests/05_class.pp
puppet apply --modulepath=modules --noop manifests/06_file_server.pp
puppet apply --modulepath=modules --noop manifests/07_template.pp
puppet apply --modulepath=modules --noop manifests/08_function.pp
```

Use real (non-noop) runs only after the syntax and environment checks succeed.
