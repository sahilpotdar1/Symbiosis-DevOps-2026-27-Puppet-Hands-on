# Puppet Fundamentals - 90 Minute Hands-on Lab

This lab is designed for 4th-year CSE DevOps students and uses Puppet Core with `puppet apply` locally. No Puppet Server, VM, Vagrant, or multi-node network is required.

## Student environments

- macOS students: run Puppet Core natively on macOS.
- Windows students: run the lab inside the Ubuntu WSL environment already used for the Ansible practical.

## What the lab covers

1. Architecture and components (explained in the instruction document)
2. Installation and verification
3. Puppet coding style
4. Resources and manifests
5. User creation
6. Package installation
7. Classes and modules
8. Module file serving (`puppet:///modules/...`)
9. EPP templates
10. Custom Puppet-language function
11. Type/provider concept using the `package` resource
12. Idempotency and repeated runs

## Folder structure

```text
puppet_lab/
├── README.md
├── manifests/
│   ├── 01_basics.pp
│   ├── 02_user.pp
│   ├── 03_package.pp
│   ├── 04_file.pp
│   ├── 05_class.pp
│   ├── 06_file_server.pp
│   ├── 07_template.pp
│   ├── 08_function.pp
│   ├── 09_provider.pp
│   └── 10_final_challenge.pp
├── modules/
│   └── puppet_lab/
│       ├── manifests/init.pp
│       ├── files/hello.txt
│       ├── templates/welcome.epp
│       └── functions/greeting.pp
├── docs/
│   └── Puppet_Fundamentals_Hands_On_Guide.docx
└── student_scripts/
    ├── run_all_macos.sh
    └── run_all_wsl.sh
```

## Important safety note

The lab creates one local user named `devopsstudent`, installs the small `tree` package, and writes files under `/tmp/puppet-lab`. Students should run system-changing manifests with administrator/root privileges. The guide includes cleanup commands.

## Running manifests

From the lab root:

```bash
puppet apply --modulepath=modules manifests/01_basics.pp
```

On macOS, if Puppet is not on PATH, use:

```bash
/opt/puppetlabs/bin/puppet apply --modulepath=modules manifests/01_basics.pp
```

On WSL, after installation, Puppet normally exposes `/opt/puppetlabs/bin` through the installed profile script; otherwise use the full path.
