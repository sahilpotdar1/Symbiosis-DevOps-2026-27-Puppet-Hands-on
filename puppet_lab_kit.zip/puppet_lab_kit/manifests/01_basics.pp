# 01_basics.pp
# Demonstrates basic Puppet coding style and a file resource.

file { '/tmp/puppet-lab':
  ensure => directory,
}

file { '/tmp/puppet-lab/hello.txt':
  ensure  => file,
  content => "Hello from Puppet!\n",
  require => File['/tmp/puppet-lab'],
}

notify { 'basics_complete':
  message => '01_basics.pp completed successfully.',
}
