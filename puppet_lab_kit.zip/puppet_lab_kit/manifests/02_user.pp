# 02_user.pp
# Required syllabus activity: user creation.

user { 'devopsstudent':
  ensure     => present,
  comment    => 'Created by Puppet Fundamentals lab',
  managehome => false,
}

notify { 'user_demo_complete':
  message => 'User resource evaluated. Verify with: puppet resource user devopsstudent',
}
