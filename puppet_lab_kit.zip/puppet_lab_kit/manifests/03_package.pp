# 03_package.pp
# Package installation demonstration
#
# macOS:
# Uses Homebrew through exec.
#
# Ubuntu / WSL:
# Uses Puppet's apt package provider.

if $facts['os']['family'] == 'Darwin' {

  $brew_user = $facts['identity']['user']

  exec { 'install_tree_with_homebrew':
    command     => '/opt/homebrew/bin/brew install tree',
    environment => ["HOME=/Users/${brew_user}"],
    path        => ['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin'],
    unless      => '/opt/homebrew/bin/brew list tree >/dev/null 2>&1',
  }

} elsif $facts['os']['family'] == 'Debian' {

  package { 'tree':
    ensure   => installed,
    provider => apt,
  }

} else {

  fail("Unsupported operating system family: ${facts['os']['family']}")

}