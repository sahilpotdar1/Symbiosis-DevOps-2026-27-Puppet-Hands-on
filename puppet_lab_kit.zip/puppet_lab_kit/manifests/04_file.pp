# 04_file.pp
# Demonstrates file resources, attributes and idempotency.

file { '/tmp/puppet-lab/app.conf':
  ensure  => file,
  mode    => '0644',
  content => "APP_NAME=puppet-demo\nENVIRONMENT=classroom\n",
}
