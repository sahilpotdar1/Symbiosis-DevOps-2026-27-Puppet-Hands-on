# 05_class.pp
# Demonstrates classes and module loading.

class { 'puppet_lab':
  message => 'Hello from the puppet_lab class',
}
