# 06_file_server.pp
# Demonstrates module-based file serving with a puppet:/// URL.
# This does not require a standalone Puppet Server.

file { '/tmp/puppet-lab/hello-from-module.txt':
  ensure => file,
  source => 'puppet:///modules/puppet_lab/hello.txt',
}
