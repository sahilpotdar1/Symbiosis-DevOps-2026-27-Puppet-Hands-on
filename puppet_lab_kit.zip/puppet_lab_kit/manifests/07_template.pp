# 07_template.pp
# Demonstrates EPP templates.

file { '/tmp/puppet-lab/welcome.html':
  ensure  => file,
  content => epp('puppet_lab/welcome.epp', {
    'student_name' => 'DevOps Student',
    'hostname'     => $facts['networking']['hostname'],
  }),
}
