# 08_function.pp
# Demonstrates a custom function written in the Puppet language.

$message = puppet_lab::greeting('DevOps Student')

notify { 'custom_function_demo':
  message => $message,
}
