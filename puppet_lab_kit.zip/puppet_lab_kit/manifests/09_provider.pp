# 09_provider.pp
# Demonstrates Puppet resource types and providers.

if $facts['os']['family'] == 'Darwin' {

  notify { 'macOS provider':
    message => 'On macOS, Puppet uses the pkgdmg provider for native package management.',
  }

  package { 'tree':
    ensure   => absent,
    provider => pkgdmg,
  }

} elsif $facts['os']['family'] == 'Debian' {

  notify { 'Ubuntu provider':
    message => 'On Ubuntu/WSL, Puppet uses the apt provider for package management.',
  }

  package { 'tree':
    ensure   => installed,
    provider => apt,
  }

} else {

  fail("Unsupported operating system family: ${facts['os']['family']}")

}