# 10_final_challenge.pp
# End-to-end Puppet classroom challenge.
#
# macOS:
#   User is managed by Puppet.
#   tree is installed through Homebrew executed as the
#   currently logged-in macOS user.
#
# Ubuntu / WSL:
#   User and tree package are managed through Puppet.

class { 'puppet_lab':
  message => 'Final Puppet lab configuration',
}

user { 'devopsstudent':
  ensure     => present,
  comment    => 'Managed by Puppet Final Challenge',
  managehome => false,
}

if $facts['os']['family'] == 'Darwin' {

  exec { 'install_tree_with_homebrew':
    command => '/bin/sh -c \'u=$(/usr/bin/stat -f %Su /dev/console); h=$(/usr/bin/dscl . -read "/Users/$u" NFSHomeDirectory | /usr/bin/awk "{print \$2}"); /usr/bin/sudo -u "$u" env HOME="$h" /opt/homebrew/bin/brew install tree\'',
    unless  => '/bin/sh -c \'u=$(/usr/bin/stat -f %Su /dev/console); h=$(/usr/bin/dscl . -read "/Users/$u" NFSHomeDirectory | /usr/bin/awk "{print \$2}"); /usr/bin/sudo -u "$u" env HOME="$h" /opt/homebrew/bin/brew list tree >/dev/null 2>&1\'',
    path    => ['/opt/homebrew/bin', '/usr/bin', '/bin'],
    require => User['devopsstudent'],
  }

} elsif $facts['os']['family'] == 'Debian' {

  package { 'tree':
    ensure   => installed,
    provider => apt,
  }

} else {

  fail("Unsupported operating system family: ${facts['os']['family']}")

}

file { '/tmp/puppet-lab/final.txt':
  ensure  => file,
  content => "Managed by Puppet on ${facts['os']['name']}\n",
  require => File['/tmp/puppet-lab'],
}