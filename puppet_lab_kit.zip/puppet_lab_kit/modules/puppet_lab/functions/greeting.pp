function puppet_lab::greeting(String $name) >> String {
  "Hello ${name}. This message came from a custom Puppet function."
}
