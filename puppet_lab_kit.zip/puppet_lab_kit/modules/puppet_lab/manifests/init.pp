class puppet_lab(
  String $message = 'Hello from puppet_lab'
) {

  file { '/tmp/puppet-lab':
    ensure => directory,
  }

  file { '/tmp/puppet-lab/module-message.txt':
    ensure  => file,
    content => "${message}\n",
    require => File['/tmp/puppet-lab'],
  }
}
