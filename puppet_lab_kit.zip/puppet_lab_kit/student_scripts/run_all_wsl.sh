#!/bin/bash
set -e
PUPPET="$(command -v puppet || true)"
if [ -z "$PUPPET" ] && [ -x /opt/puppetlabs/bin/puppet ]; then
  PUPPET=/opt/puppetlabs/bin/puppet
fi
if [ -z "$PUPPET" ]; then
  echo "Puppet was not found. Re-open the WSL terminal after installation and try again."
  exit 1
fi
cd "$(dirname "$0")/.."
for f in manifests/01_basics.pp manifests/02_user.pp manifests/03_package.pp manifests/04_file.pp manifests/05_class.pp manifests/06_file_server.pp manifests/07_template.pp manifests/08_function.pp manifests/09_provider.pp manifests/10_final_challenge.pp; do
  echo "============================================================"
  echo "Running $f"
  sudo "$PUPPET" apply --modulepath=modules "$f"
done
echo "All lab manifests completed."
